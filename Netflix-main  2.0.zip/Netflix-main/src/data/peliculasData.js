// src/data/peliculas.js
const peliculasData = [
  {
    id: 1,
    titulo: "Inception",
    descripcion: "Un ladrón que roba secretos corporativos...",
    imagen: "https://url-de-la-imagen.jpg"
  },
  {
    id: 2,
    titulo: "Interstellar",
    descripcion: "Un equipo de exploradores viaja a través del espacio...",
    imagen: "https://url-de-la-imagen.jpg"
  }
];

export default peliculasData;
